import React from 'react';
import ShortPulling from './components/ShortPulling';
import LongPulling from './components/LongPulling';
import WS from './components/WS';
import SSE from './components/SSE';
import './App.css';

function App() {

  
  return (
    <SSE />
  );
}

export default App;
