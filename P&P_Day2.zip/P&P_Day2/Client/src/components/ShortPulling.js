import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ShortPulling = () => {
    
    const [messages, setMessages] = useState([]);
    // const [users, setUsernames] = useState([]);
    
    const [input, setInput] = useState('');
    const [inputName , setInputName] = useState('');
    
    useEffect(()=>{
      setInterval(()=>axios.get('http://localhost:3000/messages').then((res)=>{
        // console.log(res.data);
        setMessages((res.data));
        // setUsernames(res.data);
      }),10*1000) 
    },[]);


    const msghandleChange = (e) =>{
      const {target: {value}} = e;
      setInput(value);
    }
    const namehandleChange = (e) =>{
      const {target: {value}} = e;
      setInputName(value);
    }
    const handleSubmit = (e) => {
      e.preventDefault();
      axios.post('http://localhost:3000/messages',{content:input,username:inputName});
    }
    return(
        <div>
      <form id="form" onSubmit={handleSubmit}>
        <h2>Short pulling</h2>
        <input id="content" type="text" placeholder="message" name="content" onChange={msghandleChange} value={input}/>
        <input id="content" placeholder="username" type="text" name="username" onChange={namehandleChange} value={inputName}/>
        <button type="submit">Send</button>
      </form>
        <div className="App">
          {
            messages.map(m => <h1 key={m.content}>message is:{m.content} user is:{m.username}</h1>)
          }
          
        </div>
    </div>
    );




}
export default ShortPulling;