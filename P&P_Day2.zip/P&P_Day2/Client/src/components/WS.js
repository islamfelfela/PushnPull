import React,{useState,useEffect} from 'react';
import io from 'socket.io-client';
// import axios from 'axios';

const socket = io.connect('http://localhost:3000')
const WS = (props)=>{
    const [messages, setMessages] = useState([]);
    const [input, setInput] = useState('');

    useEffect(()=>{
        socket.on('new-message',(message)=>setMessages(messages=>messages.concat(message)));
    },[]);

    const handleChange = (e) =>{
        const {target: {value}} = e;
        setInput(value);
      }
      const handleSubmit = (e) => {
        e.preventDefault();
        socket.emit('message',input);
        setInput('');
      }
      return (
          <div>
              <form id="form" onSubmit={handleSubmit}>
              <input id="content" type="text" placeholder="message" name="content" onChange={handleChange} value={input}/>
              <button type="submit">Send</button>
              </form>
              <div className="App">
          {
            messages.map(m => <h1 key={m}>message is:{m}</h1>)
          }
          
        </div>
          </div>
      )
    
}
export default WS;