import React,{useState,useEffect} from 'react';
import axios from 'axios';

const SSE = (props)=>{
    const [messages, setMessages] = useState([]);
    const [input, setInput] = useState('');

    useEffect(()=>{
        const eventSource = new EventSource('http://localhost:3000/subscribe');
        eventSource.onmessage = (e)=>{
            console.log(e.data);
            const data = JSON.parse(e.data);
            setMessages(messages => messages.concat(data));
        };
    },[]);
    

    const handleChange = (e) =>{
        const {target: {value}} = e;
        setInput(value);
      }
      const handleSubmit = (e) => {
        e.preventDefault();
        axios.post('http://localhost:3000/messages/subscriber',{content:input}).then(()=>setInput(''));  
      }
      return (
        <div>
            <form id="form" onSubmit={handleSubmit}>
            <input id="content" type="text" placeholder="message" name="content" onChange={handleChange} value={input}/>
            <button type="submit">Send</button>
            </form>
            <div className="App">
        {
          messages.map(m => <h1 key={m.content}>message is:{m.content}</h1>)
        }   
      </div>
        </div>
    )


}
export default SSE;