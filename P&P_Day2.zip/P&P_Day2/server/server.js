const express = require('express');
const cors = require('cors');
const app = express();

app.use(express.json());
app.use(cors()); 

const subscribers = {};
app.get('/subscribe',(req,res)=>{
    const id = Math.ceil(Math.random()*10000);
    req.on('close',()=> delete subscribers[id])
    res.writeHead(200,{
        'Content-Type':'Text/event-stream',
        'Cache-Control':'no-cache',
        Connection: 'Keep-alive',
    });
    subscribers[id]= res;
});

app.post('/messages/subscriber',(req,res)=>{
    const { body } = req;
    Object.keys(subscribers).forEach((subId)=>{subscribers[subId].write(`data: ${JSON.stringify(body)}\n\n`);
    });
    res.status(204).end();
});
const socketio = require('socket.io');
const serve = require('http').createServer(app);
const io = socketio(serve);

io.on('connection',(client)=>{
    client.on('message',(message)=>{
        console.log(message);
        io.emit('new-message',message);
    });
});



serve.listen(3000, ()=>{
    console.log('server is listening to 3000')
});
